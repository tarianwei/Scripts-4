

//独立COOKIE文件     ck在``里面填写，多账号换行
let qqreadbodyVal=``

let qqreadtimeurlVal=``

let qqreadtimeheaderVal=``





let qqreadcookie = {
        qqreadbodyVal: qqreadbodyVal,
        qqreadtimeurlVal: qqreadtimeurlVal,
        qqreadtimeheaderVal: qqreadtimeheaderVal
}

module.exports =  qqreadcookie
  









